package com.diman.tugas_gis;

import androidx.fragment.app.FragmentActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.PolylineOptions;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.location_map);
        mapFragment.getMapAsync(this);
    }


    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        //  tambah koordinat marker
        LatLng luwuk = new LatLng (-0.9486787653045774, 122.79209429677411);
        LatLng rumahku = new LatLng(-1.2801492740839695, 122.55883945831947);

//    atur ukuran marker
        int tinggi = 100;
        int lebar = 100;

        BitmapDrawable bitmapStart = (BitmapDrawable)getResources().getDrawable(R.drawable.pin_map_hitam);
        BitmapDrawable bitmapDes = (BitmapDrawable)getResources().getDrawable(R.drawable.pin_map_merah);

        Bitmap s = bitmapStart.getBitmap();
        Bitmap d = bitmapDes.getBitmap();

        Bitmap markerStart = Bitmap.createScaledBitmap(s, lebar, tinggi, false);
        Bitmap markerDes = Bitmap.createScaledBitmap(d, lebar, tinggi, false);

//    tambahkan marker ke map
        mMap.addMarker(new MarkerOptions().position(luwuk).title("Marker in kota luwuk")
        .snippet("Ini kota terbersih di luwuk")
        .icon(BitmapDescriptorFactory.fromBitmap(markerStart)));

        mMap.addMarker(new MarkerOptions().position(rumahku).title("Marker in rumahku")
                .snippet("Ini rumahku tempat tinggalku")
                .icon(BitmapDescriptorFactory.fromBitmap(markerDes)));

        mMap.addPolyline(new PolylineOptions().add(
                luwuk,
                new LatLng(-0.9593956379866528, 122.79159299861588),
                new LatLng(-0.9773192606845079, 122.7854557093317),
                new LatLng(-0.9853098106145907, 122.79119562010419),
                new LatLng(-0.9904749626126533, 122.79512525141699),
                new LatLng(-1.0001430458512395, 122.79830427893339),
                new LatLng(-1.007868662483198, 122.79578754884298),
                new LatLng(-1.0124598774090137, 122.79101900761903),
                new LatLng(-1.0586947223314727, 122.75283625512489),
                new LatLng(-1.0712520177403437, 122.74377882942137),
                new LatLng(-1.0819793413922383, 122.73013550314177),
                new LatLng(-1.1127043047282565, 122.71472605010014),
                new LatLng(-1.128199100753964, 122.71437282470437),
                new LatLng(-1.1351297948125814, 122.7054097331166),
                new LatLng(-1.1358802511236203, 122.70554219259503),
                new LatLng(-1.1345117718219409, 122.69569603803077),
                new LatLng(-1.136409984877476, 122.66938075444281),
                new LatLng(-1.1397649632973454, 122.66483297875958),
                new LatLng(-1.149388431541389, 122.66372914977256),
                new LatLng(-1.161263217311613, 122.6580333919304),
                new LatLng(-1.1693857183691785, 122.63909168651308),
                new LatLng(-1.1732262407111453, 122.63502959566853),
                new LatLng(-1.1833351764716482, 122.63661910942673),
                new LatLng(-1.204524092234116, 122.62606650410919),
                new LatLng(-1.2178112241427557, 122.6342789918623),
                new LatLng(-1.2284660937020826, 122.63417341526858),
                new LatLng(-1.2341902528785267, 122.62966516228813),
                new LatLng(-1.2455934625567848, 122.60536567811779),
                new LatLng(-1.2403200476882876, 122.60180415826325),
                new LatLng(-1.2406806233991152, 122.59864838117691),
                new LatLng(-1.239508752159301, 122.59616884203767),
                new LatLng(-1.242663789087049, 122.58683675811422),
                new LatLng(-1.2438356589281827, 122.58647609787579),
                new LatLng(-1.2445117374460029, 122.58354573343848),
                new LatLng(-1.2482527021093877, 122.58390639367693),
                new LatLng(-1.251948589682997, 122.58007437864356),
                new LatLng(-1.2539857519650757, 122.57827718501741),
                new LatLng(-1.2558810659721806, 122.57929567478335),
                new LatLng(-1.2675736090812784, 122.55474264357528),
                new LatLng(-1.2727235178203837, 122.55242223188299),
                new LatLng(-1.277969972239277, 122.5559207348148),
                rumahku
        ).width(10)
                .color(Color.RED));

        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(luwuk, 11.5f));
    }
}
